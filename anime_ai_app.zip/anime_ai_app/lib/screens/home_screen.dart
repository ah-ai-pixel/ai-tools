import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:http/http.dart' as http;
import 'package:gal/gal.dart';
import '../services/replicate_service.dart';

class HomeScreen extends StatefulWidget {
  final String apiToken;
  const HomeScreen({super.key, required this.apiToken});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final ImagePicker _picker = ImagePicker();
  File? _originalImage;
  String? _resultImageUrl;
  bool _isLoading = false;
  String? _errorMessage;

  late final ReplicateService _replicateService;

  @override
  void initState() {
    super.initState();
    _replicateService = ReplicateService(apiToken: widget.apiToken);
  }

  Future<void> _pickImage(ImageSource source) async {
    final XFile? picked = await _picker.pickImage(
      source: source,
      imageQuality: 90,
      maxWidth: 1280,
    );
    if (picked == null) return;

    setState(() {
      _originalImage = File(picked.path);
      _resultImageUrl = null;
      _errorMessage = null;
    });
  }

  Future<void> _generateAnime() async {
    if (_originalImage == null) return;

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _resultImageUrl = null;
    });

    try {
      final resultUrl = await _replicateService.generateAnimeImage(_originalImage!);
      setState(() {
        _resultImageUrl = resultUrl;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  Future<void> _saveToGallery() async {
    if (_resultImageUrl == null) return;
    try {
      final response = await http.get(Uri.parse(_resultImageUrl!));
      await Gal.putImageBytes(response.bodyBytes, name: 'anime_result');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Збережено в галерею ✨')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Не вдалося зберегти: $e')),
        );
      }
    }
  }

  void _showImageSourceSheet() {
    showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_library),
              title: const Text('Обрати з галереї'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.gallery);
              },
            ),
            ListTile(
              leading: const Icon(Icons.camera_alt),
              title: const Text('Зробити фото'),
              onTap: () {
                Navigator.pop(context);
                _pickImage(ImageSource.camera);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Anime AI'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    children: [
                      _buildImagePreviewArea(),
                      const SizedBox(height: 16),
                      if (_errorMessage != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Text(
                            _errorMessage!,
                            style: const TextStyle(color: Colors.red),
                            textAlign: TextAlign.center,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              _buildButtons(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImagePreviewArea() {
    if (_isLoading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 60),
        child: Column(
          children: [
            SpinKitPulse(color: Colors.deepPurple, size: 60),
            SizedBox(height: 16),
            Text('Генеруємо аніме-версію...'),
          ],
        ),
      );
    }

    if (_resultImageUrl != null) {
      return Column(
        children: [
          const Text('Результат', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: Image.network(_resultImageUrl!, fit: BoxFit.cover),
          ),
        ],
      );
    }

    if (_originalImage != null) {
      return ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Image.file(_originalImage!, fit: BoxFit.cover),
      );
    }

    return Container(
      height: 300,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(16),
      ),
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.image, size: 64, color: Colors.grey),
            SizedBox(height: 8),
            Text('Оберіть фото для перетворення'),
          ],
        ),
      ),
    );
  }

  Widget _buildButtons() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _isLoading ? null : _showImageSourceSheet,
            icon: const Icon(Icons.add_photo_alternate),
            label: const Text('Обрати фото'),
          ),
        ),
        const SizedBox(height: 8),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: (_originalImage != null && !_isLoading) ? _generateAnime : null,
            icon: const Icon(Icons.auto_awesome),
            label: const Text('Перетворити в аніме'),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.deepPurple, foregroundColor: Colors.white),
          ),
        ),
        if (_resultImageUrl != null) ...[
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _saveToGallery,
              icon: const Icon(Icons.download),
              label: const Text('Зберегти в галерею'),
            ),
          ),
        ],
      ],
    );
  }
}
