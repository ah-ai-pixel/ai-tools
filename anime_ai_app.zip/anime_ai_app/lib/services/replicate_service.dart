import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

/// Сервіс для звернення до Replicate API, який запускає модель
/// перетворення звичайного фото у стиль японського аніме.
///
/// Отримати API токен: https://replicate.com/account/api-tokens
class ReplicateService {
  // Базовий URL Replicate API
  static const String _baseUrl = 'https://api.replicate.com/v1';

  // Версія моделі AnimeGANv2 (img2img, стилізація фото під аніме).
  // Можна замінити на іншу модель з https://replicate.com/explore
  static const String _modelVersion =
      'cjwbw/animeganv2:1e8f0e2c2e19bc3a2e9b8f36eba9c6ef6a2b7f96d5f80eb5f96b8f6b6dbb2c1a';

  final String apiToken;

  ReplicateService({required this.apiToken});

  /// Завантажує локальний файл фото і запускає генерацію.
  /// Повертає URL готового аніме-зображення.
  Future<String> generateAnimeImage(File imageFile) async {
    // 1. Кодуємо фото в base64 data URI (Replicate приймає такий формат
    //    без потреби у власному file-hosting)
    final bytes = await imageFile.readAsBytes();
    final base64Image = base64Encode(bytes);
    final mimeType = imageFile.path.endsWith('.png') ? 'image/png' : 'image/jpeg';
    final dataUri = 'data:$mimeType;base64,$base64Image';

    // 2. Створюємо запит на генерацію (prediction)
    final createResponse = await http.post(
      Uri.parse('$_baseUrl/predictions'),
      headers: {
        'Authorization': 'Token $apiToken',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'version': _modelVersion.split(':').last,
        'input': {
          'image': dataUri,
        },
      }),
    );

    if (createResponse.statusCode != 201) {
      throw ReplicateException(
        'Не вдалося створити запит: ${createResponse.statusCode} ${createResponse.body}',
      );
    }

    final createData = jsonDecode(createResponse.body) as Map<String, dynamic>;
    final predictionUrl = createData['urls']['get'] as String;

    // 3. Опитуємо статус, поки генерація не завершиться
    //    (Replicate працює асинхронно — це може зайняти 5-30 секунд)
    while (true) {
      await Future.delayed(const Duration(seconds: 2));

      final statusResponse = await http.get(
        Uri.parse(predictionUrl),
        headers: {'Authorization': 'Token $apiToken'},
      );

      if (statusResponse.statusCode != 200) {
        throw ReplicateException(
          'Помилка перевірки статусу: ${statusResponse.statusCode}',
        );
      }

      final statusData = jsonDecode(statusResponse.body) as Map<String, dynamic>;
      final status = statusData['status'] as String;

      if (status == 'succeeded') {
        final output = statusData['output'];
        // output може бути рядком або списком URL — залежно від моделі
        if (output is List && output.isNotEmpty) {
          return output.last as String;
        } else if (output is String) {
          return output;
        }
        throw ReplicateException('Модель не повернула зображення');
      } else if (status == 'failed' || status == 'canceled') {
        throw ReplicateException(
          'Генерація не вдалася: ${statusData['error'] ?? 'невідома помилка'}',
        );
      }
      // якщо status == 'starting' або 'processing' — просто чекаємо далі
    }
  }
}

class ReplicateException implements Exception {
  final String message;
  ReplicateException(this.message);

  @override
  String toString() => message;
}
