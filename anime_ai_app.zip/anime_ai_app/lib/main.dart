import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'screens/api_key_setup_screen.dart';
import 'screens/home_screen.dart';

void main() {
  runApp(const AnimeAiApp());
}

class AnimeAiApp extends StatelessWidget {
  const AnimeAiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Anime AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorSchemeSeed: Colors.deepPurple,
        useMaterial3: true,
      ),
      home: const _StartupGate(),
    );
  }
}

/// Перевіряє, чи вже збережений API токен, і показує потрібний екран.
class _StartupGate extends StatefulWidget {
  const _StartupGate();

  @override
  State<_StartupGate> createState() => _StartupGateState();
}

class _StartupGateState extends State<_StartupGate> {
  final _storage = const FlutterSecureStorage();
  String? _token;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadToken();
  }

  Future<void> _loadToken() async {
    final token = await _storage.read(key: 'replicate_api_token');
    setState(() {
      _token = token;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_token == null || _token!.isEmpty) {
      return const ApiKeySetupScreen();
    }
    return HomeScreen(apiToken: _token!);
  }
}
